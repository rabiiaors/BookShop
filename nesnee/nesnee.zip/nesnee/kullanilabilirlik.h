#include<string>
#ifndef KULLANILABILIRLIK_H
#define KULLANILABILIRLIK_H
using namespace std;
class kullanilabilirlik
{ 
    private:
    	int kacinciel;
	public:
		void setkacinciel(int k);
         int getkacinciel();
         public:
        void yazdir();
};


#endif
