#include <fstream>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#ifndef BOOKSHOPE_H
#define BOOKSHOPE_H
#include "bookshope.h"
using namespace std;
 
// Bookshop Class
class bookshope {
public:
    void kontrolpaneli();
    void kitapekle();
    void listegoster();
    void kitapkontrol();
    void kitapguncelle();
    void kitapsil();
    void ucrethesapla();
};

#endif
