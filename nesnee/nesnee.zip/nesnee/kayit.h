#include<string>
#ifndef KAYIT_H
#define KAYIT_H
using namespace std;
class kayit{
    public: 
    	string kitapadi;
    	string yazar;
    	int fiyat;
    	void bilgilerigoster();
    void toplamtutarhesapla();
    	
};


#endif
